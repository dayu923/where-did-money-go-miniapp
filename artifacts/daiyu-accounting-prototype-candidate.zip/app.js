const icons = { 餐饮: ['☕', 'icon-food'], 交通: ['↗', 'icon-transport'], 购物: ['◇', 'icon-shopping'], 居家: ['⌂', 'icon-home'], 娱乐: ['♫', 'icon-entertainment'], 其他: ['·', 'icon-shopping'], 工资: ['↙', 'icon-income'] };
const entries = [
  { type: 'expense', category: '餐饮', note: '和朋友吃了顿好吃的', amount: 86, date: '2026-11-19' },
  { type: 'expense', category: '交通', note: '地铁出行', amount: 6, date: '2026-11-19' },
  { type: 'expense', category: '购物', note: '日常补货', amount: 128.5, date: '2026-11-18' },
  { type: 'expense', category: '餐饮', note: '午餐', amount: 32, date: '2026-11-18' },
  { type: 'income', category: '工资', note: '月工资', amount: 8500, date: '2026-11-15' },
  { type: 'expense', category: '餐饮', note: '周末聚餐', amount: 1128, date: '2026-11-12' },
  { type: 'expense', category: '交通', note: '通勤与出行', amount: 370, date: '2026-11-10' },
  { type: 'expense', category: '居家', note: '换了新的床单', amount: 680, date: '2026-11-08' },
  { type: 'expense', category: '购物', note: '生活用品', amount: 455.5, date: '2026-11-03' },
  { type: 'expense', category: '娱乐', note: '看展和电影', amount: 400.5, date: '2026-11-01' },
];
const currency = new Intl.NumberFormat('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const money = (value) => currency.format(value);
const dateLabel = (value) => new Intl.DateTimeFormat('zh-CN', { month: 'long', day: 'numeric', weekday: 'short' }).format(new Date(`${value}T00:00:00`));
const iconFor = (category) => icons[category] || icons.其他;

function renderTransactions(target, filter = 'all', limit = Infinity) {
  const visible = entries.filter((entry) => filter === 'all' || entry.type === filter).slice(0, limit);
  const groups = visible.reduce((map, entry) => map.set(entry.date, [...(map.get(entry.date) || []), entry]), new Map());
  target.innerHTML = groups.size ? [...groups].map(([date, items]) => `<div class="transaction-group"><div class="group-date">${dateLabel(date)}</div>${items.map((entry) => {
    const [icon, iconClass] = iconFor(entry.category);
    return `<div class="transaction-row"><span class="category-icon ${iconClass}" aria-hidden="true">${icon}</span><div class="transaction-info"><div class="transaction-title">${entry.category}</div><div class="transaction-note">${escapeHtml(entry.note || '—')}</div></div><div class="transaction-amount ${entry.type}">${entry.type === 'income' ? '+' : '−'} ¥${money(entry.amount)}</div></div>`;
  }).join('')}</div>`).join('') : '<div class="empty-state">还没有这类账单，记下第一笔吧。</div>';
}

function renderCategories(target) {
  const totals = entries.filter((entry) => entry.type === 'expense').reduce((result, entry) => {
    result[entry.category] = (result[entry.category] || 0) + entry.amount;
    return result;
  }, {});
  const total = Object.values(totals).reduce((sum, amount) => sum + amount, 0);
  target.innerHTML = Object.entries(totals).sort((a, b) => b[1] - a[1]).map(([category, amount]) => {
    const percent = Math.round(amount / total * 100);
    const [icon, iconClass] = iconFor(category);
    return `<div class="category-item"><span class="category-icon ${iconClass}" aria-hidden="true">${icon}</span><div class="category-meta"><b>${category}</b><small>${percent}% 的支出</small><div class="category-bar"><span style="width:${percent}%"></span></div></div><div class="category-value"><b>¥${money(amount)}</b><small>${percent}%</small></div></div>`;
  }).join('');
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

function refresh() {
  renderTransactions(document.querySelector('#home-transactions'), 'all', 4);
  renderTransactions(document.querySelector('#all-transactions'), currentFilter);
  renderCategories(document.querySelector('#home-categories'));
  renderCategories(document.querySelector('#review-categories'));
  const expense = entries.filter((entry) => entry.type === 'expense').reduce((sum, entry) => sum + entry.amount, 0);
  const [whole, decimal] = money(expense).split('.');
  document.querySelector('#month-total').textContent = whole;
  document.querySelector('.big-amount small').textContent = `.${decimal}`;
  document.querySelector('.share-total').innerHTML = `¥${whole}<span>.${decimal}</span>`;
  document.querySelector('.review-stats article:first-child strong').textContent = `¥${money(expense)}`;
}

let currentFilter = 'all';
const titles = { home: '早上好，小鱼', transactions: '每一笔，都有迹可循', review: '月度复盘', share: '分享生活的小结' };
function navigate(page) {
  const activePage = document.querySelector(`#page-${page}`) ? page : 'home';
  document.querySelectorAll('.page').forEach((section) => section.classList.toggle('active', section.id === `page-${activePage}`));
  document.querySelectorAll('[data-page]').forEach((link) => link.classList.toggle('active', link.dataset.page === activePage));
  document.querySelector('#page-title').textContent = titles[activePage];
  history.replaceState(null, '', `#${activePage}`);
  window.scrollTo(0, 0);
}

document.querySelectorAll('[data-page]').forEach((link) => link.addEventListener('click', (event) => {
  event.preventDefault();
  navigate(link.dataset.page);
}));
document.querySelectorAll('[data-open-entry]').forEach((button) => button.addEventListener('click', () => {
  const form = document.querySelector('#entry-form');
  const now = new Date();
  form.elements.date.value = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  document.querySelector('#entry-dialog').showModal();
}));
document.querySelector('[data-close-entry]').addEventListener('click', () => document.querySelector('#entry-dialog').close());
document.querySelector('#entry-form').addEventListener('change', (event) => {
  if (event.target.name === 'type') {
    const category = document.querySelector('#entry-form').elements.category;
    category.value = event.target.value === 'income' ? '工资' : '餐饮';
  }
});
document.querySelector('#entry-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  entries.unshift({ type: form.get('type'), category: form.get('category'), note: form.get('note').trim(), amount: Number(form.get('amount')), date: form.get('date') });
  refresh();
  document.querySelector('#entry-dialog').close();
  event.currentTarget.reset();
  showToast('记下啦，今天也有好好生活。');
});
document.querySelector('#filter-toggle').addEventListener('click', () => {
  const filters = document.querySelector('#filters');
  filters.hidden = !filters.hidden;
});
document.querySelectorAll('[data-filter]').forEach((button) => button.addEventListener('click', () => {
  currentFilter = button.dataset.filter;
  document.querySelectorAll('[data-filter]').forEach((item) => item.classList.toggle('selected', item === button));
  renderTransactions(document.querySelector('#all-transactions'), currentFilter);
}));
document.querySelector('#share-copy').addEventListener('click', () => {
  const expense = entries.filter((entry) => entry.type === 'expense').reduce((sum, entry) => sum + entry.amount, 0);
  const month = new Intl.DateTimeFormat('zh-CN', { month: 'long' }).format(new Date());
  const summary = `${month}生活小结：本月支出 ¥${money(expense)}。认真生活的每一天，都有好好记录。`;
  const summaryField = document.querySelector('#share-summary');
  summaryField.value = summary;
  summaryField.hidden = false;
  summaryField.focus();
  summaryField.select();
  showToast('总结文字已选中，请长按复制');
});
let toastTimer;
function showToast(message) {
  const toast = document.querySelector('.toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2300);
}

document.querySelector('#today-label').textContent = `${new Intl.DateTimeFormat('zh-CN', { month: 'long' }).format(new Date())} · 好好生活`;
navigate(location.hash.slice(1) || 'home');
refresh();
